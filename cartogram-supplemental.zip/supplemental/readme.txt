Supplementary material for "Recognition and Recall of Geographic Data In Cartograms"
EuroVis Submission # 329

1. Survey-all.pdf

-- Screenshots containing the pages of user study


2. A folder "CSVs" containing the raw data for error rate and completion time for each participant.


3. A folder "plots" containing all the plots showing the error rates and completion time
for each task, by all the participants, and by different demographic groups.


4. A folder "R-scripts" containing all our R scripts to generate the plots and run different analysis.