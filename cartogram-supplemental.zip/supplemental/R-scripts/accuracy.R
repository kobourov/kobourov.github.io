library(ggplot2)


plotDemo = function(plotData,file)
{
	pdf(paste(folder,file,"-accuracy.pdf", sep=""),height=1.5,width=1.5+0.5*nrow(plotData))

	print(ggplot(plotData,aes(x=Name,y=Accuracy)) +
	geom_bar(position=position_dodge(),stat="identity", color="steelblue4", fill="steelblue4", width=0.5) +
	labs(x = "Accuracy (%)", y = "") +
	theme(axis.text.x = element_text(size=10), axis.text.y = element_text(size=10), axis.title.x = element_text(size=14)) +
	geom_text(aes(label=Accuracy), hjust=-0.1, size=3.5) +
	coord_flip(ylim=c(0,113)))

	dev.off()
}

myData=data.frame(Name=c("Compare", "Filter", "Find-Top-k", "Summarize"), Accuracy=c(87.5, 96.88, 81.25, 84.38), check.names=FALSE)
myData$Name = factor(myData$Name, levels=c("Summarize", "Find-Top-k", "Filter", "Compare"))
plotDemo(myData, "African-American")


myData=data.frame(Name=c("Compare", "Filter", "Find-Top-k", "Summarize"), Accuracy=c(100, 81.25, 93.75, 53.13), check.names=FALSE)
myData$Name = factor(myData$Name, levels=c("Summarize", "Find-Top-k", "Filter", "Compare"))
plotDemo(myData, "Cattle-Inventory")

myData=data.frame(Name=c("Compare", "Filter", "Find-Top-k", "Summarize"), Accuracy=c(87.5, 68.75, 78.13, 71.88), check.names=FALSE)
myData$Name = factor(myData$Name, levels=c("Summarize", "Find-Top-k", "Filter", "Compare"))
plotDemo(myData, "Hispanic-Latino")

myData=data.frame(Name=c("Compare", "Filter", "Find-Top-k", "Summarize"), Accuracy=c(91, 56.25, 68.75, 87.5), check.names=FALSE)
myData$Name = factor(myData$Name, levels=c("Summarize", "Find-Top-k", "Filter", "Compare"))
plotDemo(myData, "Starbucks-per-capita")